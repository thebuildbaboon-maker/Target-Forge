# Browser rules engine

Ruleset ID: `poe1-target-legality-3.29.1.1-r6`

The modifier browser uses a two-stage filter. A modifier must pass both stages before it appears in the list.

## 1. Candidate evidence

A RePoE modifier is considered only when at least one local data mapping associates it with the selected base:

- an exact `mods_by_base` base branch;
- a class-level special branch from `mods_by_base`;
- a `crafting_bench_options.json` item-class mapping;
- an `essences.json` item-class mapping.

The bundled demonstration data uses explicit `applies_to` tags instead.

The old fallback that scanned every modifier and accepted the first matching tag has been removed. Missing candidate evidence now produces an empty or smaller pool rather than false-positive modifiers.

## 2. Final base-context validation

Each candidate is checked again by `rules-engine.js`:

- explicit base/tag assignment;
- allowed or denied item classes and base IDs;
- ordinary modifier domain compatibility;
- ordered `spawn_weights`, using the first matching base tag exactly as documented by RePoE;
- prefix, suffix or implicit generation type;
- source-specific candidate provenance.

Influence modifiers are checked with their potential influence item tag and then remain disabled in the UI until that influence is selected.

`generation_weights` are retained in imported modifier data but are not used as a universal final-item prohibition. They are context multipliers for particular generation methods. A zero multiplier under a temporary craft tag, such as a metamod or fossil context, does not prove that the modifier can never coexist on the finished item when order of operations or transfer mechanics are considered.

## Current target-state validation

A modifier that is legal for the base can still be visible but unavailable. The app disables it when:

- the item level is too low;
- its required influence is absent;
- the prefix, suffix or implicit capacity is full;
- an existing modifier shares any modifier group;
- crafted modifiers are disabled;
- an incompatible synthesis, eldritch, fracture or influence state is selected;
- the required acquisition/transfer mechanic is excluded and prepared bases are disallowed.

Optional open-prefix and open-suffix constraints automatically clear when the user deliberately fills the final physical slot. Once the physical side is full, all remaining modifiers on that side become unavailable.

## Export evidence

Every selected modifier in `agent-target-v3` contains:

```json
{
  "base_compatibility": {
    "ruleset_id": "poe1-target-legality-3.29.1.1-r6",
    "candidate_scope": "base",
    "candidate_sources": ["mods_by_base:..."],
    "evidence": []
  }
}
```

This lets the persistent ChatGPT crafting agent trust that the HTML application performed the base legality check without receiving the whole modifier database in every message.

## Elevated influence level normalization

Some game-data exports encode upgrade-only elevated influence variants at an internal modifier level of 100. The browser does not treat that internal sentinel as a final-item level requirement. Such entries are normalized as T0, require the Orb of Dominance acquisition path, and export these fields separately:

- `required_item_level`: direct final-item gate (`1` for upgrade-only T0 variants);
- `precursor_required_item_level`: the ordinary T1 unlock level when a sibling tier can be identified;
- `raw_data_required_level`: the unmodified data-export value;
- `item_level_rule`: `no_direct_requirement_upgrade_only`.

This prevents the target builder from raising the item level to an artificial or misleading value while preserving the information an optimizer needs to plan the precursor or donor item.
