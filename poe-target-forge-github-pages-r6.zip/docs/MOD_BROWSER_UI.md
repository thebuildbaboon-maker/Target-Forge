# Modifier browser UI

The r5 modifier browser uses a compact data-pool workflow inspired by the interaction patterns players already know from Craft of Exile, while retaining PoE Target Forge's own styling and target-validation behavior.

## Hierarchy

1. **Crafting source** — Natural, Crafting Bench, Essence, Influence and other source families.
2. **Affix side** — Prefixes and suffixes are shown in parallel where the viewport is wide enough. Implicits span the full pool width.
3. **Modifier family** — Modifiers sharing the same primary modifier group are collapsed into one row.
4. **Tier** — Expanding a family shows each tier with its rendered stat, required item level, spawn weight and add control.

Grouping by the primary modifier group is important: different tiers from the same family cannot be selected as separate affixes, and the existing rules engine still checks all modifier-group intersections before allowing a tier to be added.

## Sorting

The pool can sort families by:

- modifier-family name;
- highest required item level in the family;
- highest known spawn weight in the family;
- name A–Z.

Tiers inside a family are always ordered from best tier to lower tiers where tier metadata is available, otherwise by required item level and weight.

## Expansion behavior

- **Open all groups** opens every source and family matching the active filters.
- **Collapse all** collapses unselected families. Families containing selected modifiers remain open so the chosen tier stays visible.
- Search automatically opens every matching family.
- Selecting a tier keeps its family open after the pool re-renders.

## Availability

Base-incompatible modifiers never reach this UI. A tier that is compatible with the base but blocked by the current item state remains visible and disabled when **Show unavailable** is enabled. The first blocking reason appears directly beneath the tier.


## r5 compact tier selector

Each modifier family is rendered as two lines: the family name, tier dropdown and add control on the first line; the selected tier text, source, item-level requirement and weight on the second. Upgrade-only influence variants are labeled T0 and display them as upgrade-only and show the precursor T1 unlock level separately from the raw internal level.
