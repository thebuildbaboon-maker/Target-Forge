# Craft of Exile coverage review

Reviewed against the PoE 1 interface and changelog available for patch 3.29.1.1 on 2026-08-02.

## Added or matched in this release

- Current patch selection is pinned in the package ID and export.
- Modifier browser and base-specific applicable pools through RePoE.
- Item-level and modifier-group legality.
- Physical item-limit enforcement, including magic/rare limits, jewels/trinkets/grafts, Focused Amulet and Simplex Amulet.
- Open prefix/suffix target requirements with automatic reconciliation.
- Influence limits and synthesis/eldritch/fracture incompatibilities.
- Explicit fractured-state target requirements.
- Elevated influence-modifier target requirements.
- Target item quality requirement.
- Special-source pools: essence, fossil/Delve, Incursion, Betrayal/unveil, influence, eldritch, synthesis, corruption, Infamous, recombinator and Allflame.
- Drop-only source classification and prepared-base requirements.
- User-controlled mechanic access and custom strategy constraints.
- Reusable agent knowledge package and compact per-target JSON.
- Current 3.29 Talisman fracture, Fractured Fossil, Allflame, Ducat and socket-rule updates.
- GitHub Pages deployment workflow.

## Intentionally not duplicated

- Interactive currency-by-currency item emulator.
- Monte Carlo crafting-process simulation.
- Fossil optimizer and exact calculator UI.
- Live inventory, account/OAuth and item storage.
- Live poe.ninja pricing and custom pricing calculations.
- Full item import/export compatibility with every external format.

These are not required for target legality or the ChatGPT handoff. The agent package is instructed to use a current simulator or complete mod pool whenever exact stochastic odds are needed, and never to invent missing numbers.

## Remaining data-dependent boundary

The browser can load current RePoE data, but its bundled offline dataset is representative rather than exhaustive. Exact stat translations and every exceptional base property depend on the loaded data snapshot. Action-level formulas that are opaque or displayed only in game—especially selected recombinator success chances—are represented as known rules with unknown exact odds, not reverse-engineered estimates.
