'use strict';
const assert = require('assert');
const rules = require('../rules-engine.js');

const boots = { id:'boots', name:'Dragonscale Boots', item_class:'Boots', domain:'item', tags:['boots','str_dex_armour','armour','evasion_armour'] };
const armour = { id:'armour', name:'Astral Plate', item_class:'Body Armour', domain:'item', tags:['body_armour','str_armour','armour'] };
const ring = { id:'ring', name:'Amethyst Ring', item_class:'Ring', domain:'item', tags:['ring','jewellery'] };

const movement = { id:'move', affix:'prefix', source:'natural', raw_domain:'item', applies_to:['boots'], spawn_weights:[{tag:'boots',weight:1000},{tag:'default',weight:0}], candidate_scope:'base' };
assert.equal(rules.baseCompatibility(movement, boots).valid, true, 'boots should accept movement speed');
assert.equal(rules.baseCompatibility(movement, armour).valid, false, 'body armour should reject boot movement speed');

const cold = { id:'cold', affix:'prefix', source:'natural', raw_domain:'item', spawn_weights:[{tag:'no_attack_mods',weight:0},{tag:'ring',weight:500},{tag:'default',weight:0}], candidate_scope:'base' };
let result = rules.baseCompatibility(cold, ring);
assert.equal(result.valid, true, 'ordered spawn weights should reach ring when no_attack_mods is absent');
assert.equal(result.evidence.find(e => e.rule === 'ordered_spawn_weight').matched_tag, 'ring');

const impossible = { id:'impossible', affix:'suffix', source:'natural', raw_domain:'item', spawn_weights:[{tag:'body_armour',weight:0},{tag:'default',weight:1000}], candidate_scope:'base' };
result = rules.baseCompatibility(impossible, armour);
assert.equal(result.valid, false, 'first matching zero rule must block even when default is positive');
assert.equal(result.reasons[0].code, 'SPAWN_WEIGHT');

const essence = { id:'ess', affix:'suffix', source:'essence', raw_domain:'crafted', is_essence_only:true, allowed_item_classes:['Boots'], candidate_scope:'class' };
assert.equal(rules.baseCompatibility(essence, boots).valid, true, 'essence class mapping should allow boots');
assert.equal(rules.baseCompatibility(essence, ring).valid, false, 'essence class mapping should reject rings');

const a = {id:'a', groups:['MaximumLife'], type:'MaximumLife'};
const b = {id:'b', groups:['MaximumLife'], type:'MaximumLife'};
assert.equal(rules.groupConflict(b,[a]).group,'MaximumLife','shared groups must conflict');

assert.deepEqual(rules.affixLimits({name:'Simplex Amulet',item_class:'Amulet'},'rare'),{prefix:1,suffix:2,implicit:3});
assert.deepEqual(rules.affixLimits({name:'Cobalt Jewel',item_class:'Jewel'},'rare'),{prefix:2,suffix:2,implicit:3});
assert.deepEqual(rules.affixLimits(boots,'magic'),{prefix:1,suffix:1,implicit:3});

const influenceFamily = [
  {
    id:'InfluenceTier1', name:'of Shaping', affix:'suffix', source:'influence', influence:'shaper',
    type:'InfluenceFamily', group:'InfluenceFamily', required_level:85, raw_required_level:85,
    spawn_weights:[{tag:'shaper_item',weight:500},{tag:'default',weight:0}], weight:500
  },
  {
    id:'ElevatedInfluenceTier', name:'Elevated of Shaping', affix:'suffix', source:'influence', influence:'shaper',
    type:'InfluenceFamily', group:'InfluenceFamily', required_level:100, raw_required_level:100,
    spawn_weights:[{tag:'default',weight:0}], weight:null
  }
];
rules.annotateInfluenceUpgradeTiers(influenceFamily);
assert.equal(influenceFamily[0].required_level,85,'ordinary influence tier should retain its true item level');
assert.equal(influenceFamily[1].tier,'T0','upgrade-only influence modifier should be labeled T0');
assert.equal(influenceFamily[1].required_level,1,'T0 target should not inherit the raw internal item level');
assert.equal(influenceFamily[1].precursor_required_level,85,'T0 should retain the T1 precursor unlock level separately');
assert.equal(influenceFamily[1].raw_required_level,100,'raw internal level should remain available for traceability');
assert.equal(influenceFamily[1].acquisition_mechanic,'orb_of_dominance','T0 should require Orb of Dominance');


let influenceRule = rules.influenceCompatibility({influence:'hunter'}, new Set(), {maximum:2});
assert.equal(influenceRule.valid, true, 'first influence modifier should be selectable without a manual toggle');
assert.equal(influenceRule.auto_activate, true, 'first influence should be auto-activated');
assert.deepEqual(influenceRule.projected, ['hunter']);

influenceRule = rules.influenceCompatibility({influence:'redeemer'}, new Set(['hunter']), {maximum:2});
assert.equal(influenceRule.valid, true, 'second distinct influence modifier should remain selectable');
assert.deepEqual(new Set(influenceRule.projected), new Set(['hunter','redeemer']));

influenceRule = rules.influenceCompatibility({influence:'shaper'}, new Set(['hunter','redeemer']), {maximum:2});
assert.equal(influenceRule.valid, false, 'a third distinct influence modifier must be disabled');
assert.equal(influenceRule.code, 'INFLUENCE_LIMIT');

influenceRule = rules.influenceCompatibility({influence:'hunter'}, new Set(['hunter','redeemer']), {maximum:2});
assert.equal(influenceRule.valid, true, 'mods using either existing influence remain selectable at the two-influence cap');
assert.equal(influenceRule.auto_activate, false);

console.log('rules-engine tests passed');
