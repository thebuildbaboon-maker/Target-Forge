#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
css = (ROOT / 'styles.css').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="styles.css" />', f'<style>\n{css}\n</style>')
for filename in ['rules-engine.js', 'mechanics-data.js', 'sample-data.js', 'app.js']:
    source = (ROOT / filename).read_text(encoding='utf-8').replace('</script', '<\\/script')
    html = html.replace(f'<script src="{filename}"></script>', f'<script>\n{source}\n</script>')
out = ROOT / 'dist' / 'poe-target-forge-standalone.html'
out.write_text(html, encoding='utf-8')
print(out)
