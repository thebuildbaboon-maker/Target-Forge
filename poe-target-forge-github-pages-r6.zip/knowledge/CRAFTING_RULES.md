# Path of Exile 1 Crafting Rules — 3.29.1.1

This document is a planning ruleset, not a complete stochastic simulator. Datamined modifier applicability and weights should come from the target builder/RePoE snapshot. Patch-specific action behavior takes precedence over historical guides.

## 1. Item legality

### Explicit affixes

- Ordinary rare equipment normally has up to three prefixes and three suffixes.
- Magic items normally have up to one prefix and one suffix.
- Rare jewels, Abyss jewels, trinkets and graft-like two-sided items use two prefixes and two suffixes unless the base declares another limit.
- Focused Amulet: two prefixes and one suffix.
- Simplex Amulet: one prefix and two suffixes.
- A requested open prefix/suffix reduces usable capacity by one. In the builder, deliberately filling the last physical slot clears the optional open-slot request rather than creating an impossible item.
- Implicit, enchantment and explicit pools are separate, but actions may overwrite one implicit family with another.

### Modifier eligibility

A modifier must satisfy all of:

- correct game patch and release state;
- compatible domain and item class/base tags;
- sufficient item level;
- source requirements;
- a remaining affix slot;
- no shared modifier group with another selected explicit;
- required influence or special item state;
- action-specific generation restrictions.

Ordered spawn-weight rules are evaluated using the first matching item tag. A zero resulting weight means the modifier cannot be naturally selected in that context.

### Item states

- Conventional Shaper/Elder/Conqueror influence cannot coexist with synthesised, fractured or eldritch-influenced item states.
- Synthesised and eldritch implicit families do not coexist as independent families; applying eldritch implicits overwrites relevant synthesis implicits.
- Fractured items cannot receive ordinary influence or become synthesised. Some transfer mechanics can produce unusual finished combinations only where the current mechanic explicitly permits them.
- Mirrored items are normally immutable.
- Corrupted items accept only actions explicitly supporting corrupted items.
- Split state restricts further splitting/copying actions.

## 2. Crafted modifiers and metamods

- A normal item may have one crafted modifier.
- “Can have up to 3 Crafted Modifiers” allows up to three crafted modifiers total, including itself.
- More crafted modifiers can exist on recombined results when the current recombinator allows their transfer; this is not the same as bench-crafting more than the normal limit.
- A bench craft requires a compatible open affix and obeys ordinary modifier groups.
- Prefixes Cannot Be Changed and Suffixes Cannot Be Changed protect only actions that explicitly respect metamods.
- Cannot Roll Attack/Caster changes eligible random mod pools only for actions that respect it.
- Essences at the tiers that reforge a rare item do not preserve affixes merely because a metamod is present.
- Recombinators do not respect metamods.
- Always check the exact action before claiming protection.

## 3. Core currency families

- Transmute/Alchemy/Binding create magic/rare item states from eligible normal bases.
- Alteration rerolls a magic item; Augmentation adds a missing magic affix; Regal upgrades magic to rare with an added explicit.
- Chaos-style actions reroll rare explicits subject to the action’s current metamod behavior.
- Exalted-style actions add an eligible explicit to an open slot.
- Annulment-style actions remove an eligible explicit; special variants may target one side or state.
- Scouring removes removable modifiers while respecting action-specific protections.
- Divine/Blessed/Volatile effects modify values rather than modifier identity, with their own eligibility rules.
- Ancient/Chance-style unique transformations are base/drop-pool sensitive.
- Mirror effects create mirrored copies and should be treated as terminal for ordinary crafting.

## 4. Forced, biased and targeted crafting

### Essences

Essences force their listed modifier and reforge the remaining rare-item affixes. The forced modifier still consumes a prefix or suffix and can conflict by modifier group. Multiple essence-exclusive modifiers may coexist only through a legal transfer/recombination route; ordinary essence use does not force several at once.

### Fossils

Fossils alter tag weights, block tagged modifiers, add special fossil-only outcomes or alter item state. Calculate using the complete eligible pool after all fossil multipliers and zero-weight exclusions. Special fossils have individual restrictions. In 3.29, Fractured Fossil fractures a random modifier and cannot be used on fractured or influenced items; it is no longer the old split-copy action.

### Harvest

Treat each Harvest craft as a separate action: tagged reforge/augment, conversion, enchantment, influence reforge or influence randomisation. Do not assume removed historical crafts exist. In 3.29 the Harvest option to synthesise a non-unique item was removed.

### Bestiary

Bestiary includes imprints, aspect crafts, add/remove or metamod-related crafts, corruption and base-specific recipes. In 3.29 the old split recipes were replaced by Talisman fracture recipes, and Talisman imprint/base-reroll behavior changed. Bestiary synthesis implicit reroll is restricted to unique items.

### Betrayal and unveil

Distinguish:

- drop-only Betrayal modifiers;
- veiled modifiers placed by current veiled currency/actions;
- the unveil selection action;
- weaker bench-crafted versions unlocked from unveiling.

A bench version is not automatically equivalent to the native unveiled/drop-only modifier.

### Rog

Rog performs a sequence of offered mutations. Route evaluation must condition on the actual offers; do not describe a non-guaranteed future offer as deterministic.

## 5. Influence and eldritch

- Influence Exalted Orbs add the matching influence and an eligible influenced modifier, subject to item-state restrictions.
- Awakener’s Orb combines two influence types and transfers one eligible influenced modifier from each item according to its current rules; other modifiers are rerolled/generated as specified by the action.
- Orb of Dominance removes one eligible influenced modifier and elevates another; it requires the correct influenced-mod setup.
- Eldritch Embers/Ichors create their respective implicit family on eligible armour slots.
- Orb of Conflict changes tiers between opposing eldritch implicits according to dominance/current rules.
- Eldritch Chaos/Exalted/Annulment affect prefix or suffix sides according to eldritch dominance. They are valuable for finishing one affix side while preserving the other, but only on eligible eldritch items.

## 6. Fracture

- Fracturing Orb requires a qualifying rare item and fractures a random eligible explicit. It cannot be used on incompatible influenced, synthesised or already-fractured states.
- Current Bestiary Talisman recipes fracture one modifier on a rare Talisman with at least four modifiers, or two modifiers on a rare Talisman with at least six modifiers.
- Current Fractured Fossil fractures a random modifier and cannot be used on fractured or influenced items.
- A fractured modifier cannot be rerolled or removed by ordinary crafting.
- Multiple fractured modifiers can exist on a recombined result where current recombination permits transfer; do not infer that a Fracturing Orb can directly create them.

## 7. Corruption and irreversible finishing

- Vaal Orb, Locus of Corruption, Volatile Vaal Orb and current league corruption effects have separate outcome tables.
- Corruption may replace/add implicits, alter sockets, change rarity/identity, or leave the item unchanged depending on item type and action.
- Tainted currency is limited to corrupted items and each currency has its own action.
- Perform corruption after all required reversible crafting unless the target specifically needs corruption as an intermediate state.
- In 3.29 socket colours are normally white and corruption/socket outcomes changed; use current rules rather than pre-3.29 colour guides.

## 8. Quality, sockets, enchants and auxiliary properties

- Ordinary item quality, flask quality, jewellery catalysts, Sacred Orb base-defence percentile and special quality currencies affect different properties.
- Catalysts scale tagged jewellery explicits and may be consumed/altered by some actions.
- Tailoring/Tempering Orbs apply Heist enchantments with their own eligibility.
- Anoints are enchantments and item-class specific. Current Talismans cannot be anointed.
- Instilling/Enkindling Orbs apply flask enchantments.
- Socket/link/colour actions follow current 3.29 white-socket rules; historical RGB bench recipes are not current.
- Engineer’s/Infused Engineer’s Orbs affect strongboxes, not ordinary equipment.

## 9. Current Allflame systems

- The Allflame item generator produces visible ghostly outcomes and lets the player keep one; model it as a multi-outcome transformation/acquisition action.
- Intangibility and Cursed Ducats have individual rules. Do not generalise one Ducat’s behavior to another.
- Allflame-created states cannot always be reverted by traditional imprint logic.
- Pantheon Aspect and other league-only modifiers require the matching current league source or a permitted prepared base.

## 10. Strategy principles

- Start from the hardest-to-acquire, least replaceable property: special base/implicit, fractured mod, influence-transfer mod or drop-only donor.
- Use forced mods before low-odds random completion when doing so does not destroy a rarer state.
- Construct the side with the more restrictive mod pool first when the other side has a deterministic eldritch/bench finish.
- Reserve an affix only when the final strategy actually needs it.
- Treat all irreversible steps as terminal branches.
- A “blocking mod” is useful only when it removes legal outcomes for the exact next action. Group conflicts, filled affix sides, metamods and tag blocks are not interchangeable.

## Elevated influence variants and exported levels

Elevated influence modifiers are upgrade outcomes, not ordinary item-level-100 spawn tiers. In target JSON, `required_item_level` is therefore not derived from the raw sentinel level. `precursor_required_item_level` records the T1 unlock level when it can be matched, while `raw_data_required_level` is provenance only. The final item can also receive an elevated modifier through transfer, so the precursor level must not be imposed blindly on the destination base.
