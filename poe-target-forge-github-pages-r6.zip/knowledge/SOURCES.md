# Sources and freshness

Verified 2026-08-02 for Path of Exile 1 patch 3.29.1.1.

Authoritative/current sources take precedence over historical wiki text.

- Official Path of Exile 3.29 patch notes:
  https://www.pathofexile.com/forum/view-thread/3985332
  Used for current Allflame systems, socket changes, Talisman changes, synthesis removal, Bestiary changes and Fractured Fossil behavior.

- Official Path of Exile 3.26 patch notes and related official update notes:
  https://www.pathofexile.com/forum
  Used for selected versus unpredictable recombinator mode and the current penalty affecting pools heavy in non-natural/exclusive modifiers.

- Craft of Exile current PoE 1 interface and changelog:
  https://www.craftofexile.com/?game=poe1
  https://beta.craftofexile.com/changelog?game=poe1
  Used as a coverage comparison for current patch data, item-limit checks, open-affix requirements, special jewellery, eldritch, influence, synthesis, drop-only mods, fracture state, corruption, enchants and crafting families.

- PoEDB Recombinator reference:
  https://poedb.tw/us/Recombinator
  Used for classic unpredictable recombinator base inheritance and affix-pool count distributions.

- Path of Exile community wiki:
  https://www.poewiki.net/wiki/Crafting
  https://www.poewiki.net/wiki/Recombinator
  Used for explanatory cross-checks. Patch notes override stale wiki statements.

- RePoE normalized game-data export:
  https://github.com/repoe-fork/repoe
  https://repoe-fork.github.io/
  Used by the site for base/mod applicability, modifier groups, tags, required levels, weights and stat records. Export schemas can change and are adapted at runtime.

## Confidence labels

- `official`: official patch notes or developer documentation.
- `datamined`: current game data exported by RePoE/PoEDB.
- `implemented-reference`: behavior cross-checked against Craft of Exile.
- `community-documented`: community wiki/guide; verify when patch-sensitive.
- `unknown`: no complete current formula is public; agent must not invent it.

## Browser legality data contracts

The r3 browser rules engine follows the RePoE data contracts documented here:

- `mods.json`: https://github.com/repoe-fork/repoe/blob/master/RePoE/docs/mods.md
  Ordered `spawn_weights`, modifier groups, domains, required levels, added tags and generation weights.
- `base_items.json`: https://github.com/repoe-fork/repoe/blob/master/RePoE/docs/base_items.md
  Base domains, item classes and immutable base tags.
- `crafting_bench_options.json`: https://github.com/repoe-fork/repoe/blob/master/RePoE/docs/crafting_bench_options.md
  Exact item-class lists for bench-added modifiers.
- `essences.json`: https://github.com/repoe-fork/repoe/blob/master/RePoE/docs/essences.md
  Exact Essence modifier assignment by item class.
