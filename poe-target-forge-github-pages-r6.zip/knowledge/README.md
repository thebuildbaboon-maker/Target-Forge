# Install this package once

Use these files as the persistent knowledge for a ChatGPT Project or custom GPT:

1. Add `AGENT_INSTRUCTIONS.md` to the project instructions, or paste its contents into the custom GPT instruction field.
2. Upload the remaining files in this directory as knowledge.
3. In PoE Target Forge, configure the mechanics you can access and build the target.
4. Copy **Agent target JSON** and send only that JSON for each evaluation.

The JSON package ID must match `poe1-crafting-knowledge-3.29.1.1-r3`. When the live game patch changes, update both the site data and this package before relying on patch-sensitive strategy advice.

Exact market cost needs a live league price snapshot. Exact weighted crafting odds need a complete current competing mod pool or a current simulator; the agent must label unknown numbers rather than estimate from memory.
