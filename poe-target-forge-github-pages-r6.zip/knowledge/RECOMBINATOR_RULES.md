# Recombinator Rules — Current Planning Guide

## Two distinct modes

### Selected-modifier mode

- The player selects desired modifiers.
- The game displays a success chance.
- Failure may destroy both inputs and produce no output.
- The displayed in-game chance is authoritative. Do not substitute the classic pool-count table or a community estimate.
- Use this mode when preserving named valuable modifiers is worth input-destruction risk.

### Unpredictable mode

- Produces an output rather than using selected-mod failure/destruction behavior.
- One input base is selected for the output. Base-tied properties follow the selected base under the current rules, including applicable influence/state, quality, implicits, enchants and anoints.
- Prefixes from both items form one pool; suffixes form another.
- A number of prefixes and suffixes is selected separately, then legal modifiers are chosen for the final item.
- Recombinators do not respect metamods.

## Classic pool-count table

The documented classic table for the number selected from each affix-side pool is:

| Mods in one side’s combined pool | Outcome count distribution |
|---|---|
| 1 | 1 mod: 66.6%; 0 mods: 33.3% |
| 2 | 2 mods: 33.3%; 1 mod: 66.6% |
| 3 | 3 mods: 20%; 2 mods: 50%; 1 mod: 30% |
| 4 | 3 mods: 35%; 2 mods: 55%; 1 mod: 10% |
| 5 | 3 mods: 50%; 2 mods: 50% |
| 6 | 3 mods: 70%; 2 mods: 30% |

This table determines how many modifiers are attempted, not the complete probability that a particular target set survives. Modifier eligibility, groups, duplicate/exclusive behavior, base restrictions and current weighting still matter.

## Current exclusive/non-natural modifier caveat

Current recombination reduces average retention when pools contain many modifiers that cannot naturally generate on the resulting base, including several exclusive/source-only classes. Therefore:

- old “exclusive mod filling” recipes and deterministic-looking blocking formulas must not be copied blindly;
- adding extra essence, veiled, crafted, fractured, legacy or other non-natural modifiers can change outcomes differently from adding ordinary natural mods;
- exact selected-modifier odds must come from the in-game displayed chance;
- exact unpredictable odds involving exclusive pools should be marked unknown unless verified against the current implementation or a current simulator.

## Blocking and odds-improvement principles

These are planning principles, not universal formulas:

1. **Choose the correct output base.** Only modifiers legal on the chosen output base can survive as ordinary legal explicits. Preserve the base whose implicits, influence, enchantment, anoint, quality or item state must remain.
2. **Separate prefix and suffix goals.** The count roll occurs per side. Extra mods on the opposite side do not improve the desired side’s count roll.
3. **Use pool-size thresholds intentionally.** Moving a side from one pool size to another changes the count distribution. More total mods can increase the chance that more mods are selected, but can lower the chance that any particular mod is among them.
4. **Avoid same-group collisions.** Two modifiers sharing a modifier group cannot coexist on the finished item. A conflicting filler is not a safe neutral blocker.
5. **Prefer legal natural fillers when a filler is needed.** Current penalties make non-natural/exclusive fillers unreliable for recreating old blocking techniques.
6. **Do not rely on metamods.** Prefixes/Suffixes Cannot Be Changed and Cannot Roll tags do not protect or filter recombination.
7. **Model donor loss.** Selected mode can consume both valuable inputs on failure. Include the full donor-preparation cost in each attempt.
8. **Account for item level.** Output item level follows the current recombinator item-level rule; verify it remains high enough for every retained/generated target modifier.
9. **Check transfer status.** Crafted or fractured modifiers can retain their status where the current mode permits. Multiple such modifiers on a result are possible, but their creation route must be identified.
10. **Treat new-mod generation separately.** Unpredictable recombination may add a new modifier after assembling the output; the exact chance and eligible classes are patch-sensitive.

## Required reporting

For every recombinator route, report:

- mode;
- chosen output base and why;
- donor A and donor B affix pools;
- target mods by prefix/suffix;
- modifier-group collisions;
- natural versus exclusive/non-natural pool members;
- count-table result where applicable;
- exact odds source (`displayed in game`, `documented table plus complete weights`, or `unknown`);
- cost of losing both donors;
- usable failure outputs and restart condition.
